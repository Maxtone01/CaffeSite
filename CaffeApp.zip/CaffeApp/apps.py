from django.apps import AppConfig


class CaffeappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'CaffeApp'
