from django import forms

from CaffeApp.models import Customer


class Ip_Join(forms.ModelForm):
    class Meta:
        model = Customer
        fields = ['ip']
