from django.http import HttpResponse


def allow_by_ip(view_func):
    allowedIps = ['129.0.0.1', '127.0.0.1']

    def authorize(request):
        user_ip = request.META['REMOTE_ADDR']
        for ip in allowedIps:
            if ip == user_ip:
                return view_func(request)
    return authorize
